# Simple python app

This application display a list of messages.

## Run it

Start it using docker-compose. You can then access the page at http://localhost:5000

```
docker-compose up -d
```
